<?php

require_once 'RecurringContributionDefaultSetting.civix.php';

/**
 * Implementation of hook_civicrm_config
 */
function recurringContribution_defaultsetting_civicrm_config(&$config) {
  _RecurringContributionDefaultSetting_civix_civicrm_config($config);
}

/**
 * Implementation of hook_civicrm_xmlMenu
 *
 * @param $files array(string)
 */
function recurringContribution_defaultsetting_civicrm_xmlMenu(&$files) {
  _RecurringContributionDefaultSetting_civix_civicrm_xmlMenu($files);
}

/**
 * Implementation of hook_civicrm_install
 */
function recurringContribution_defaultsetting_civicrm_install() {
  return _RecurringContributionDefaultSetting_civix_civicrm_install();
}

/**
 * Implementation of hook_civicrm_uninstall
 */
function RecurringContributionDefaultSetting_civicrm_uninstall() {
  return _RecurringContributionDefaultSetting_civix_civicrm_uninstall();
}

/**
 * Implementation of hook_civicrm_enable
 */
function recurringContribution_defaultsetting_civicrm_enable() {
   return _RecurringContributionDefaultSetting_civix_civicrm_enable();
}

/**
 * Implementation of hook_civicrm_disable
 */
function recurringContribution_defaultsetting_civicrm_disable() {
    return _RecurringContributionDefaultSetting_civix_civicrm_disable();
}

/**
 * Implementation of hook_civicrm_upgrade
 *
 * @param $op string, the type of operation being performed; 'check' or 'enqueue'
 * @param $queue CRM_Queue_Queue, (for 'enqueue') the modifiable list of pending up upgrade tasks
 *
 * @return mixed  based on op. for 'check', returns array(boolean) (TRUE if upgrades are pending)
 *                for 'enqueue', returns void
 */
function recurringContribution_defaultsetting_civicrm_upgrade($op, CRM_Queue_Queue $queue = NULL) {
  return _RecurringContributionDefaultSetting_civix_civicrm_upgrade($op, $queue);
}

/**
 * Implementation of hook_civicrm_managed
 *
 * Generate a list of entities to create/deactivate/delete when this module
 * is installed, disabled, uninstalled.
 */
function recurringContribution_defaultsetting_civicrm_managed(&$entities) {
  return _RecurringContributionDefaultSetting_civix_civicrm_managed($entities);
}

/***
 *  Get Contribution page Recurring checkbox default TRUE/FALSE. 
 * 
 * **/
   function getContributionPageRecurringDefaultValue($pageID){
	  if(CRM_Utils_Type::escape($pageID,'Integer',FALSE)){
		  $sql="SELECT is_default FROM civicrm_contributionpage_recurring_setting WHERE contributionpageid =%1 ";
		  $params=array(1=>array($pageID,'Integer'));
		  $dao=CRM_Core_DAO::executeQuery($sql,$params);
		  if($dao->fetch()) {
			return $dao->is_default;
		  }else{
			  
			  return FALSE;
		  }
		  
	  }else{
		  
		  return FALSE;
	  } 
	   
   }
   
   /**
    *  CIVICRM SET Contribution Page Recurring checkbox default TRUE/FALSE
    * 
    * **/
    
    function setContributionPageRecurringDefaultValue($pageID,$value){
		
		if(CRM_Utils_Type::escape($pageID,'Integer',FALSE)){
			$recordExist=getContributionPageRecurringDefaultValue($pageID);
			 if($recordExist!==FALSE){
			 
			 $sql=" UPDATE civicrm_contributionpage_recurring_setting set is_default = %2 where contributionpageid =%1 ";
			 $params= array(1 => array($pageID, 'Integer'),
						    2 => array($value, 'Integer'));
			 $result=CRM_Core_DAO::executeQuery($sql,$params);
		    }else{
				$sql=" INSERT INTO civicrm_contributionpage_recurring_setting set is_default = %2 , contributionpageid =%1 ";
				$params= array(1 => array($pageID, 'Integer'),
						       2 => array($value, 'Integer'));
			    $result=CRM_Core_DAO::executeQuery($sql,$params);
				return $result;
			 }
		 }
	}
   
   
/**
 *   Alter Civicrm Contribution Page AMOUNT Section
 * **/
 
 function recurringContribution_defaultsetting_civicrm_buildForm($formName, &$form){
	if (($formName == 'CRM_Contribute_Form_ContributionPage_Amount') ){
		if($form->elementExists('is_recur')){
			$PageId=$form->getVar( '_id' );
			$defaults=array();
			if($PageId){
				$defaults['is_recur_set_default']=getContributionPageRecurringDefaultValue($PageId);
			}
			$form->addElement('checkbox', 'is_recur_set_default', ts('Recurring Contributions set by default on public page'), NULL);
			$form->setDefaults( $defaults );
			if (isset($_REQUEST['snippet']) && $_REQUEST['snippet']) {
			if ($_REQUEST['snippet'] == 5) {
			$smarty = CRM_Core_Smarty::singleton();
			$tmp = $form->toSmarty();
            $smarty->assign('form', $tmp);
            $smarty->fetch("CRM/recuringContributionDefaultSetting.tpl",NULL,NULL,true);
		    }
		  }
		}
				 
	 }
	 /**
	  *  Set Recurring Default For Online Payment
	  * 
	  * **/
	  if (($formName == 'CRM_Contribute_Form_Contribution_Main') ){
		if($form->elementExists('is_recur')){
			$PageId=$form->getVar( '_id' );
			$defaults=array();
			if($PageId){
				$form->getElement('is_recur')->freeze();
				$defaults['is_recur']=getContributionPageRecurringDefaultValue($PageId);
			}
			$form->setDefaults( $defaults );
		}
				 
	 }
 }
 
 /**
  * 
  *  Post Process Amount Contribution
  * **/
  
  function recurringContribution_defaultsetting_civicrm_postProcess($formName, &$form){
	  if (($formName == 'CRM_Contribute_Form_ContributionPage_Amount') ){
		  $PageId=$form->getVar( '_id' );
		  $params=$form->getVar('_submitValues');
		  if (CRM_Utils_array::crmIsEmptyArray($params)) {
			  $params=$_POST;
		  }
		  if($is_recur=CRM_Utils_Array::value('is_recur',$params,FALSE)){
		    $recuringDefaultValue=CRM_Utils_Array::value('is_recur_set_default',$params,0);
		    setContributionPageRecurringDefaultValue($PageId,$recuringDefaultValue);
	      }
		  
	  }
  }
  
  
  /***
   *  Alter Form Content If in JSON FORMAT
   * 
   * **/
   
function recurringContribution_defaultsetting_civicrm_alterContent( &$content, $context, $tplName, &$object ) {
  if($context == "form") {
    if($tplName == "CRM/Contribute/Form/ContributionPage/Amount.tpl") {
		if(is_a($object,'CRM_Contribute_Form_ContributionPage_Amount')){
			if (isset($_REQUEST['snippet']) && $_REQUEST['snippet']) {
				if($_REQUEST['snippet'] == 'json'){
					  $smarty = CRM_Core_Smarty::singleton();
					  $html = $smarty->fetch("CRM/recuringContributionDefaultSetting.tpl");
					  $content=$html.$content;
				}
			}
	    }
    }
  }
}
